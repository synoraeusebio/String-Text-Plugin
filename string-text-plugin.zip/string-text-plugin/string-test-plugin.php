<?php
/**
 * Plugin Name: String Test Plugin
 * Description:       A test plugin for getting a string to appear anywhere in wp-admin
 * Version:           1.0
 * Requires at least: 5.9.2
 * Requires PHP:      7.4
 * Author:            Synora Eusebio
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

 /*
String Test Plugin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
String Test Plugin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with String Test Plugin. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
*/

/* 
Goal: To display a string of text in wp-admin once this plugin is activated. 
Things to do: 
	1. Get the plugin activated
	2. Once the plugin is activated, display a string of text in wp-admin. 
*/



//Is this even needed to activate the plugin?
function my_plugin_activate() {

     do_action('my_plugin_activate');
}
register_activation_hook(__FILE__, 'my_plugin_activate');

//Add text to the header of the admin area
function my_custom_admin_head() {
    echo "<p> Here is my string of text!</p>";
}
add_action('admin_head', 'my_custom_admin_head');

?>